package generic;

import java.io.FileInputStream;
import generic.Operand.OperandType;
import java.io.*;
import java.nio.ByteBuffer;


public class Simulator {
		
	static FileInputStream inputcodeStream = null;
	private static String objFilePath = "";
	
	public static void setupSimulation(String assemblyProgramFile, String objectProgramFile)
	{	
		int firstCodeAddress = ParsedProgram.parseDataSection(assemblyProgramFile);
		ParsedProgram.parseCodeSection(assemblyProgramFile, firstCodeAddress);
		objFilePath = objectProgramFile;
		ParsedProgram.printState();
	}
	
	public static void assemble()
	{
		try (FileOutputStream output = new FileOutputStream(objFilePath)) {
			
			final int firstInsAdd = ParsedProgram.firstCodeAddress;

			output.write(ByteBuffer.allocate(4).putInt(firstInsAdd).array());

			

			for(int data_var : ParsedProgram.data){
				output.write(ByteBuffer.allocate(4).putInt(data_var).array());
			}

			for (Instruction ins : ParsedProgram.code){
				int byte_ins = 0;
				int opcode = -1;	
				boolean isFuncSet = false;
				switch (ins.getOperationType()) {
					case add: 
					if(!isFuncSet){
						opcode = 0;
						isFuncSet = true;
					}
					case sub:
					if(!isFuncSet){
						opcode = 2;
						isFuncSet = true;
					}
					case mul:
					if(!isFuncSet){
						opcode = 4;
						isFuncSet = true;
					}
					case div:
					if(!isFuncSet){
						opcode = 6;
						isFuncSet = true;
					}
					case and:
					if(!isFuncSet){
						opcode = 8;
						isFuncSet = true;
					}
					case or:
					if(!isFuncSet){
						opcode = 10;
						isFuncSet = true;
					}
					case xor:
					if(!isFuncSet){
						opcode = 12;
						isFuncSet = true;
					}
					case slt:
					if(!isFuncSet){
						opcode = 14;
						isFuncSet = true;
					}
					case sll:
					if(!isFuncSet){
						opcode = 16;
						isFuncSet = true;
					}
					case srl:
					if(!isFuncSet){
						opcode = 18;
						isFuncSet = true;
					}
					case sra:
					if(!isFuncSet){
						opcode = 20;
						isFuncSet = true;
					}
							{
								byte_ins |= (opcode & 0x1F) << 27;
								byte_ins |= (ins.getSourceOperand1().getValue() & 0x1F) << 22;
								byte_ins |= (ins.getSourceOperand2().getValue() & 0x1F) << 17;
								byte_ins |= (ins.getDestinationOperand().getValue() & 0x1F) << 12;
							}
							break;
					case addi: 
					if(!isFuncSet){
						opcode = 1;
						isFuncSet = true;
					}
					case subi:
					if(!isFuncSet){
						opcode = 3;
						isFuncSet = true;
					}
					case muli:
					if(!isFuncSet){
						opcode = 5;
						isFuncSet = true;
					}
					case divi:
					if(!isFuncSet){
						opcode = 7;
						isFuncSet = true;
					}
					case andi:
					if(!isFuncSet){
						opcode = 9;
						isFuncSet = true;
					}
					case ori:
					if(!isFuncSet){
						opcode = 11;
						isFuncSet = true;
					}
					case xori:
					if(!isFuncSet){
						opcode = 13;
						isFuncSet = true;
					}
					case slti:
					if(!isFuncSet){
						opcode = 15;
						isFuncSet = true;
					}
					case slli:
					if(!isFuncSet){
						opcode = 17;
						isFuncSet = true;
					}
					case srli:
					if(!isFuncSet){
						opcode = 19;
						isFuncSet = true;
					}
					case srai:
					if(!isFuncSet){
						opcode = 21;
						isFuncSet = true;
					}
					case load:
					if(!isFuncSet){
						opcode = 22;
						isFuncSet = true;
					} 
					case store:
					if(!isFuncSet){
						opcode = 23;
						isFuncSet = true;
					}
					case beq:
					if(!isFuncSet){
						opcode = 25;
						isFuncSet = true;
					} 
					case bne:
					if(!isFuncSet){
						opcode = 26;
						isFuncSet = true;
					} 
					case blt:
					if(!isFuncSet){
						opcode = 27;
						isFuncSet = true;
					} 
					case bgt:
					if(!isFuncSet){
						opcode = 28;
						isFuncSet = true;
					}
							{
								if(opcode < 25){
									byte_ins |= (opcode & 0x1F) << 27;
									byte_ins |= (ins.getSourceOperand1().getValue() & 0x1F) << 22;
									byte_ins |= (ins.getDestinationOperand().getValue() & 0x1F) << 17;
									byte_ins |= (ins.getSourceOperand2().getValue() & 0x1F);
								}
								else{
									byte_ins |= (opcode & 0x1F) << 27;
									byte_ins |= (ins.getSourceOperand1().getValue() & 0x1F) << 22;
									byte_ins |= (ins.getSourceOperand2().getValue() & 0x1F) << 17;
									int pc = ins.getProgramCounter();
									int addrOfLabel = ParsedProgram.symtab.get(ins.getDestinationOperand().getLabelValue()) - pc;
									int mask = 131071;
									addrOfLabel = (mask & addrOfLabel);
									byte_ins |= (addrOfLabel);
								}

							}
							break;
					case jmp:
					if(!isFuncSet){
						opcode = 24;
						isFuncSet = true;
					}
							{
								byte_ins |= (opcode & 0x1F) << 27;
								byte_ins |= (ins.getDestinationOperand().getValue() & 0x1F) << 17;
								int pc = ins.getProgramCounter();
								int addrOfLabel = ParsedProgram.symtab.get(ins.getDestinationOperand().getLabelValue()) - pc;
								int mask = 4194303;
								addrOfLabel = (mask & addrOfLabel);
								byte_ins |= (addrOfLabel);

							}
							break;
					default:
						opcode = 29;
					
							{
								byte_ins |= (opcode & 0x1F) << 27;

							}
							break;
				}

				
					
				output.write(ByteBuffer.allocate(4).putInt(byte_ins).array());
			}
		}			
		
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
